package com.feuji.kafkaconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
